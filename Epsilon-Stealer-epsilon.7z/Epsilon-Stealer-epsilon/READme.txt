Python 3.11.4 or above must be installed!
Internet connection must be available!
Disable your antivirus/defender as it might delete some important files!

Run "Builder.bat"