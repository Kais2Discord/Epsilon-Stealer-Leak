<h1 align="center"> Epsilon Stealer LEAK </h1> 
<p align= "center"> <kbd> <img  src="https://i.imgur.com/ViganW8.jpg"width="420"> </kbd><br><br>



<p align="center"><a href="https://discord.gg/MBPnjwpmNE" target="_blank">✨ Join Discord for support and contact (Click me! ) ✨ </a>







                                                      🤖 Features


-   Discord Information
    -   Nitro
    -   Badges
    -   Billing
    -   Email
    -   Phone
    -   HQ Friends
    -   HQ Guilds
    -   Gift Codes

-   Discord Injection
    - Send token, password, email and billing on login or when email/password is changed

-   Application Data
    -   Steam
    -   Riot Games
    -   Telegram

-   System Information
    -   User
    -   System
    -   Disk
    -   Network

 -   File Stealer
    -   Grabs Seed Phrases, Tokens, Private Keys, Recovery Codes, Backup Codes, 2FA codes

-   General Functions
    -   Check if being run in a VirusTotal sandbox
    -   Adds file to startup




- Grab Browser cookies & passwords




- Grab Crypto Wallets. 🦊 Metamask, 🅰️ Atomic, 👾 Exodus, 🅱️ Binance, 💰 Coinbase, 🟡 Trust, 👻 Phantom ...



    

                                                      ⬇️ Setup

                                                  


- open `builder.bat`

                                                       🖼️ Pictures
 
<div align="center">
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://i.imgur.com/DHskZdG.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src=""></img>
    



</div>
 
 


                                                      ⚠️ Disclaimer

- Cet outil est uniquement destiné à des fins éducatives. Il est codé pour vous permettre de voir comment vos fichiers sont simplement volés et comment agir. Ne pas utiliser à des fins illégales. Nous ne sommes jamais responsables d'une utilisation illégale. <bold>Educational purpose only!</bold>

                                                      🪪 Created By

#
|*Information:* | *Response:* |         *DISCORD:*            |
|---------------|------------ |-------------------------------|
| *Made By :*   | Kais LRF    |                               |
| *User :*      | MZR         |                               |
| *Server :*    |             | https://discord.gg/MBPnjwpmNE |

